<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

require_once 'includes/db.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user   = $result->fetch_assoc();

    // Acepta password_verify O texto plano (para compatibilidad con BD sin hash)
    $valid = $user && (password_verify($password, $user['password']) || $password === $user['password']);

    if ($valid) {
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role']      = $user['role_name'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Correo o contraseña incorrectos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar Sesión — Hotel Guaminga</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', sans-serif;
      min-height: 100vh;
      background: #0a0a0a;
      display: flex;
    }

    /* LEFT PANEL */
    .left-panel {
      width: 55%;
      background: linear-gradient(135deg, #0a0a0a 0%, #1a1208 50%, #0d0d0d 100%);
      display: flex; flex-direction: column;
      justify-content: center; align-items: center;
      padding: 60px 40px; position: relative; overflow: hidden;
    }
    .left-panel::before {
      content: '';
      position: absolute; inset: 0;
      background-image:
        linear-gradient(rgba(201,168,76,0.05) 1px, transparent 1px),
        linear-gradient(90deg, rgba(201,168,76,0.05) 1px, transparent 1px);
      background-size: 60px 60px;
    }
    .left-panel::after {
      content: '';
      position: absolute;
      width: 500px; height: 500px; border-radius: 50%;
      background: radial-gradient(circle, rgba(201,168,76,0.1) 0%, transparent 70%);
      top: 50%; left: 50%; transform: translate(-50%, -50%);
    }
    .left-content { position: relative; z-index: 1; text-align: center; max-width: 420px; }
    .brand { font-family: 'Playfair Display', serif; font-size: 2.2rem; color: #c9a84c; letter-spacing: 3px; margin-bottom: 8px; }
    .brand-sub { font-size: 0.72rem; letter-spacing: 5px; text-transform: uppercase; color: rgba(255,255,255,0.3); margin-bottom: 50px; }
    .left-title { font-family: 'Playfair Display', serif; font-size: 2.4rem; color: #fff; line-height: 1.2; margin-bottom: 16px; }
    .left-title em { color: #c9a84c; font-style: italic; }
    .left-desc { color: rgba(255,255,255,0.4); font-size: 0.9rem; line-height: 1.7; margin-bottom: 50px; }

    /* Quick access cards */
    .quick-title { font-size: 0.7rem; letter-spacing: 3px; text-transform: uppercase; color: rgba(201,168,76,0.7); margin-bottom: 14px; }
    .quick-cards { display: flex; flex-direction: column; gap: 10px; width: 100%; }
    .quick-card {
      display: flex; align-items: center; gap: 14px;
      background: rgba(255,255,255,0.04);
      border: 1px solid rgba(201,168,76,0.2);
      padding: 14px 18px; cursor: pointer;
      transition: all 0.3s; text-align: left;
      text-decoration: none;
    }
    .quick-card:hover { background: rgba(201,168,76,0.1); border-color: rgba(201,168,76,0.5); transform: translateX(4px); }
    .quick-card .q-icon { font-size: 1.4rem; flex-shrink: 0; }
    .quick-card .q-info { flex: 1; }
    .quick-card .q-role { font-size: 0.8rem; color: #c9a84c; font-weight: 600; letter-spacing: 1px; }
    .quick-card .q-cred { font-size: 0.75rem; color: rgba(255,255,255,0.3); margin-top: 2px; }
    .quick-card .q-arrow { color: rgba(201,168,76,0.5); font-size: 0.9rem; }

    /* RIGHT PANEL */
    .right-panel {
      width: 45%;
      background: #111;
      display: flex; flex-direction: column;
      justify-content: center; align-items: center;
      padding: 60px 50px;
    }
    .form-box { width: 100%; max-width: 360px; }
    .form-tag { font-size: 0.7rem; letter-spacing: 4px; text-transform: uppercase; color: #c9a84c; margin-bottom: 10px; }
    .form-heading { font-family: 'Playfair Display', serif; font-size: 2rem; color: #fff; margin-bottom: 6px; }
    .form-sub { color: rgba(255,255,255,0.35); font-size: 0.85rem; margin-bottom: 35px; }
    .divider-line { width: 40px; height: 1px; background: #c9a84c; margin-bottom: 35px; }

    label { font-size: 0.75rem; letter-spacing: 1.5px; text-transform: uppercase; color: rgba(255,255,255,0.5); margin-bottom: 8px; display: block; }
    .form-control {
      background: rgba(255,255,255,0.05) !important;
      border: 1px solid #2a2a2a !important;
      color: #fff !important;
      border-radius: 2px !important;
      padding: 13px 16px !important;
      font-size: 0.9rem !important;
      transition: border-color 0.3s !important;
    }
    .form-control:focus { border-color: #c9a84c !important; box-shadow: none !important; background: rgba(201,168,76,0.05) !important; }
    .form-control::placeholder { color: rgba(255,255,255,0.2) !important; }

    .btn-login {
      width: 100%; background: #c9a84c; color: #0a0a0a;
      font-weight: 700; padding: 14px; border: none; border-radius: 2px;
      font-size: 0.85rem; letter-spacing: 2px; text-transform: uppercase;
      transition: all 0.3s; cursor: pointer; margin-top: 8px;
    }
    .btn-login:hover { background: #e2c47a; transform: translateY(-1px); box-shadow: 0 8px 25px rgba(201,168,76,0.3); }

    .error-box {
      background: rgba(220,53,69,0.1); border: 1px solid rgba(220,53,69,0.3);
      color: #f08080; padding: 12px 16px; border-radius: 2px;
      font-size: 0.85rem; margin-bottom: 20px;
    }

    .register-link { text-align: center; margin-top: 28px; }
    .register-link span { color: rgba(255,255,255,0.3); font-size: 0.85rem; }
    .register-link a { color: #c9a84c; text-decoration: none; font-weight: 600; }
    .register-link a:hover { text-decoration: underline; }

    .back-link {
      position: absolute; top: 20px; left: 30px;
      color: rgba(255,255,255,0.3); font-size: 0.8rem; text-decoration: none;
      letter-spacing: 1px; transition: color 0.3s;
    }
    .back-link:hover { color: #c9a84c; }

    @media (max-width: 768px) {
      body { flex-direction: column; }
      .left-panel, .right-panel { width: 100%; padding: 40px 24px; }
      .left-panel { min-height: auto; }
      .quick-cards { flex-direction: column; }
    }
  </style>
</head>
<body>

<!-- LEFT: Branding + Quick Access -->
<div class="left-panel">
  <a href="index.php" class="back-link">← Volver al inicio</a>
  <div class="left-content">
    <div class="brand">✦ GUAMINGA</div>
    <div class="brand-sub">Sistema de Reservas</div>
    <h2 class="left-title">Acceso rápido<br>al <em>sistema</em></h2>
    <p class="left-desc">Haz clic en cualquier rol para ingresar automáticamente con las credenciales de prueba.</p>

    <div class="quick-title">Acceso directo por rol</div>
    <div class="quick-cards">

      <a class="quick-card" href="#" onclick="fillLogin('admin@hotel.com','admin123'); return false;">
        <div class="q-icon">🔐</div>
        <div class="q-info">
          <div class="q-role">Administrador</div>
          <div class="q-cred">admin@hotel.com · admin123</div>
        </div>
        <div class="q-arrow">→</div>
      </a>

      <a class="quick-card" href="#" onclick="fillLogin('gerente@hotel.com','gerente123'); return false;">
        <div class="q-icon">🏢</div>
        <div class="q-info">
          <div class="q-role">Gerente</div>
          <div class="q-cred">gerente@hotel.com · gerente123</div>
        </div>
        <div class="q-arrow">→</div>
      </a>

      <a class="quick-card" href="#" onclick="fillLogin('recepcion@hotel.com','recepcion123'); return false;">
        <div class="q-icon">🖥</div>
        <div class="q-info">
          <div class="q-role">Recepcionista</div>
          <div class="q-cred">recepcion@hotel.com · recepcion123</div>
        </div>
        <div class="q-arrow">→</div>
      </a>

      <a class="quick-card" href="#" onclick="fillLogin('cliente@hotel.com','cliente123'); return false;">
        <div class="q-icon">🧍</div>
        <div class="q-info">
          <div class="q-role">Cliente</div>
          <div class="q-cred">cliente@hotel.com · cliente123</div>
        </div>
        <div class="q-arrow">→</div>
      </a>

    </div>
  </div>
</div>

<!-- RIGHT: Form -->
<div class="right-panel">
  <div class="form-box">
    <div class="form-tag">Bienvenido</div>
    <h2 class="form-heading">Iniciar Sesión</h2>
    <p class="form-sub">Ingresa tus credenciales para continuar</p>
    <div class="divider-line"></div>

    <?php if ($error): ?>
      <div class="error-box">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" id="loginForm">
      <div class="mb-4">
        <label>Correo electrónico</label>
        <input type="email" name="email" id="emailInput" class="form-control" placeholder="correo@ejemplo.com" required>
      </div>
      <div class="mb-4">
        <label>Contraseña</label>
        <input type="password" name="password" id="passInput" class="form-control" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn-login">Ingresar al Sistema</button>
    </form>

    <div class="register-link">
      <span>¿No tienes cuenta? </span>
      <a href="register.php">Regístrate aquí</a>
    </div>
  </div>
</div>

<script>
function fillLogin(email, pass) {
  document.getElementById('emailInput').value = email;
  document.getElementById('passInput').value = pass;
  // Auto-submit after short delay so user sees the fill
  setTimeout(() => document.getElementById('loginForm').submit(), 300);
}
</script>
</body>
</html>