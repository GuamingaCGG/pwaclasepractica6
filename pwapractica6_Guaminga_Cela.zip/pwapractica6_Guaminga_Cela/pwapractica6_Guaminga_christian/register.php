<?php
// register.php
session_start();
require_once 'includes/db.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);
    $role_id  = intval($_POST['role_id']);

    // 
    if (!in_array($role_id, [4, 5])) {
        $error = "Rol no permitido en registro público.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $name, $email, $password, $role_id);
        if ($stmt->execute()) {
            $success = "Cuenta creada. <a href='login.php'>Inicia sesión</a>";
        } else {
            $error = "El email ya está registrado.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registro - Hotel</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-4">
      <div class="card shadow">
        <div class="card-body">
          <h5 class="card-title">Crear Cuenta</h5>
          <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
          <?php endif; ?>
          <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
          <?php endif; ?>
          <form method="POST">
            <div class="mb-3">
              <label>Nombre</label>
              <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
              <label>Email</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
              <label>Contraseña</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3">
              <label>Rol</label>
              <select name="role_id" class="form-select">
                <option value="4">Cliente</option>
                <option value="5">Proveedor</option>
              </select>
            </div>
            <button type="submit" class="btn btn-success w-100">Registrarse</button>
          </form>
          <p class="text-center mt-3"><a href="login.php">← Volver al login</a></p>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
