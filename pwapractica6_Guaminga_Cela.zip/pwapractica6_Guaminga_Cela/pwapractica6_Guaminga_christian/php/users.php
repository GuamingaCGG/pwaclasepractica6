<?php
// php/users.php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Administrator') {
    header("Location: ../login.php"); exit;
}
require_once '../includes/db.php';

// Eliminar usuario
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($id != $_SESSION['user_id']) {
        $conn->query("DELETE FROM users WHERE id = $id");
    }
}

$users = $conn->query("
    SELECT u.id, u.name, u.email, r.name AS role
    FROM users u JOIN roles r ON u.role_id = r.id
    ORDER BY u.id
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Usuarios</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h4>Gestión de Usuarios</h4>
  <a href="../dashboard.php" class="btn btn-secondary btn-sm mb-3">← Volver</a>

  <table class="table table-bordered">
    <thead class="table-dark">
      <tr><th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th><th>Acción</th></tr>
    </thead>
    <tbody>
    <?php while ($u = $users->fetch_assoc()): ?>
      <tr>
        <td><?= $u['id'] ?></td>
        <td><?= htmlspecialchars($u['name']) ?></td>
        <td><?= htmlspecialchars($u['email']) ?></td>
        <td><?= $u['role'] ?></td>
        <td>
          <?php if ($u['id'] != $_SESSION['user_id']): ?>
            <a href="?delete=<?= $u['id'] ?>" class="btn btn-danger btn-sm"
               onclick="return confirm('¿Eliminar usuario?')">Eliminar</a>
          <?php else: ?>
            <span class="text-muted">Tu cuenta</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
