<?php
// php/bookings.php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Administrator', 'Hotel Manager', 'Receptionist'])) {
    header("Location: ../login.php"); exit;
}
require_once '../includes/db.php';

$bookings = $conn->query("
    SELECT b.id, u.name AS client, r.room_number, r.room_type,
           b.booking_date, b.check_in_date, b.check_out_date
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN rooms r ON b.room_id = r.id
    ORDER BY b.booking_date DESC
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Reservas</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h4> Todas las Reservas</h4>
  <a href="../dashboard.php" class="btn btn-secondary btn-sm mb-3">← Volver</a>

  <table class="table table-striped">
    <thead class="table-dark">
      <tr><th>ID</th><th>Cliente</th><th>Habitación</th><th>Tipo</th><th>Reservado</th><th>Check-in</th><th>Check-out</th></tr>
    </thead>
    <tbody>
    <?php while ($b = $bookings->fetch_assoc()): ?>
      <tr>
        <td><?= $b['id'] ?></td>
        <td><?= htmlspecialchars($b['client']) ?></td>
        <td><?= $b['room_number'] ?></td>
        <td><?= $b['room_type'] ?></td>
        <td><?= $b['booking_date'] ?></td>
        <td><?= $b['check_in_date'] ?></td>
        <td><?= $b['check_out_date'] ?></td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
