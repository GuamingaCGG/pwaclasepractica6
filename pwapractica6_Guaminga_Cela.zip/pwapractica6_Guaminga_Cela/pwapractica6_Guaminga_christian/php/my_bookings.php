<?php
// php/my_bookings.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); exit;
}
require_once '../includes/db.php';

$uid = $_SESSION['user_id'];
$bookings = $conn->query("
    SELECT b.id, r.room_number, r.room_type, r.room_price,
           b.check_in_date, b.check_out_date
    FROM bookings b
    JOIN rooms r ON b.room_id = r.id
    WHERE b.user_id = $uid
    ORDER BY b.check_in_date DESC
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Mis Reservas</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h4>📄 Mis Reservas</h4>
  <a href="../dashboard.php" class="btn btn-secondary btn-sm mb-3">← Volver</a>

  <?php if ($bookings->num_rows === 0): ?>
    <p>No tienes reservas aún. <a href="make_booking.php">Reservar ahora</a></p>
  <?php else: ?>
    <table class="table table-bordered">
      <thead class="table-primary">
        <tr><th>ID</th><th>Habitación</th><th>Tipo</th><th>Precio/noche</th><th>Check-in</th><th>Check-out</th></tr>
      </thead>
      <tbody>
      <?php while ($b = $bookings->fetch_assoc()): ?>
        <tr>
          <td><?= $b['id'] ?></td>
          <td><?= $b['room_number'] ?></td>
          <td><?= $b['room_type'] ?></td>
          <td>$<?= number_format($b['room_price'], 2) ?></td>
          <td><?= $b['check_in_date'] ?></td>
          <td><?= $b['check_out_date'] ?></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
</body>
</html>
