<?php
// php/supplies.php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Supplier') {
    header("Location: ../login.php"); exit;
}
require_once '../includes/db.php';

$uid = $_SESSION['user_id'];
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = $conn->real_escape_string($_POST['name']);
    $quantity = intval($_POST['quantity']);
    $conn->query("INSERT INTO supplies (name, quantity, supplier_id) VALUES ('$name', $quantity, $uid)");
    $success = "Suministro registrado.";
}

$supplies = $conn->query("SELECT * FROM supplies WHERE supplier_id = $uid");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Suministros</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h4> Mis Suministros</h4>
  <a href="../dashboard.php" class="btn btn-secondary btn-sm mb-3">← Volver</a>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
  <?php endif; ?>

  <form method="POST" class="row g-2 mb-4">
    <div class="col-md-4">
      <input type="text" name="name" class="form-control" placeholder="Nombre del suministro" required>
    </div>
    <div class="col-md-2">
      <input type="number" name="quantity" class="form-control" placeholder="Cantidad" required>
    </div>
    <div class="col-md-2">
      <button class="btn btn-success">Agregar</button>
    </div>
  </form>

  <table class="table table-bordered">
    <thead class="table-dark">
      <tr><th>ID</th><th>Nombre</th><th>Cantidad</th></tr>
    </thead>
    <tbody>
    <?php while ($s = $supplies->fetch_assoc()): ?>
      <tr>
        <td><?= $s['id'] ?></td>
        <td><?= htmlspecialchars($s['name']) ?></td>
        <td><?= $s['quantity'] ?></td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
