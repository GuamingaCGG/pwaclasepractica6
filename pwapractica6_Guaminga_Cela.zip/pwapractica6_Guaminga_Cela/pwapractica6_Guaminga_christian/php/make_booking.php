<?php
// php/make_booking.php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Customer', 'Receptionist'])) {
    header("Location: ../login.php"); exit;
}
require_once '../includes/db.php';

$success = $error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id       = $_SESSION['user_id'];
    $room_id       = intval($_POST['room_id']);
    $check_in      = $conn->real_escape_string($_POST['check_in']);
    $check_out     = $conn->real_escape_string($_POST['check_out']);
    $booking_date  = date('Y-m-d');

    if ($check_in >= $check_out) {
        $error = "La fecha de salida debe ser posterior a la de entrada.";
    } else {
        $conn->query("INSERT INTO bookings (user_id, room_id, booking_date, check_in_date, check_out_date)
                      VALUES ($user_id, $room_id, '$booking_date', '$check_in', '$check_out')");
        $conn->query("UPDATE rooms SET is_available = FALSE WHERE id = $room_id");
        $success = "¡Reserva realizada exitosamente!";
    }
}

$rooms = $conn->query("SELECT * FROM rooms WHERE is_available = TRUE");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Hacer Reserva</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h4> Nueva Reserva</h4>
  <a href="../dashboard.php" class="btn btn-secondary btn-sm mb-3">← Volver</a>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= $success ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="alert alert-danger"><?= $error ?></div>
  <?php endif; ?>

  <form method="POST" class="col-md-5">
    <div class="mb-3">
      <label>Habitación disponible</label>
      <select name="room_id" class="form-select" required>
        <?php while ($r = $rooms->fetch_assoc()): ?>
          <option value="<?= $r['id'] ?>">
            Hab. <?= $r['room_number'] ?> - <?= $r['room_type'] ?> ($<?= $r['room_price'] ?>/noche)
          </option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="mb-3">
      <label>Fecha de entrada</label>
      <input type="date" name="check_in" class="form-control" min="<?= date('Y-m-d') ?>" required>
    </div>
    <div class="mb-3">
      <label>Fecha de salida</label>
      <input type="date" name="check_out" class="form-control" min="<?= date('Y-m-d') ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Reservar</button>
  </form>
</div>
</body>
</html>
