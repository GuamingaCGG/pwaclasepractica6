<?php
// php/rooms.php
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Administrator', 'Hotel Manager'])) {
    header("Location: ../login.php"); exit;
}
require_once '../includes/db.php';

// Agregar habitación
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $num   = intval($_POST['room_number']);
    $type  = $conn->real_escape_string($_POST['room_type']);
    $price = floatval($_POST['room_price']);
    $conn->query("INSERT INTO rooms (room_number, room_type, room_price) VALUES ($num, '$type', $price)");
}

// Eliminar habitación
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM rooms WHERE id = $id");
}

$rooms = $conn->query("SELECT * FROM rooms ORDER BY room_number");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Habitaciones</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
  <h4>🛏 Habitaciones</h4>
  <a href="../dashboard.php" class="btn btn-secondary btn-sm mb-3">← Volver</a>

  <!-- Formulario agregar -->
  <form method="POST" class="row g-2 mb-4">
    <div class="col-md-2">
      <input type="number" name="room_number" class="form-control" placeholder="Número" required>
    </div>
    <div class="col-md-3">
      <select name="room_type" class="form-select">
        <option>Simple</option>
        <option>Doble</option>
        <option>Suite</option>
      </select>
    </div>
    <div class="col-md-2">
      <input type="number" step="0.01" name="room_price" class="form-control" placeholder="Precio" required>
    </div>
    <div class="col-md-2">
      <button name="add" class="btn btn-success">Agregar</button>
    </div>
  </form>

  <!-- Tabla -->
  <table class="table table-bordered">
    <thead class="table-dark">
      <tr><th>#</th><th>Número</th><th>Tipo</th><th>Precio</th><th>Disponible</th><th>Acción</th></tr>
    </thead>
    <tbody>
    <?php while ($r = $rooms->fetch_assoc()): ?>
      <tr>
        <td><?= $r['id'] ?></td>
        <td><?= $r['room_number'] ?></td>
        <td><?= $r['room_type'] ?></td>
        <td>$<?= number_format($r['room_price'], 2) ?></td>
        <td><?= $r['is_available'] ? 'Sí' : 'No' ?></td>
        <td><a href="?delete=<?= $r['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Eliminar?')">Eliminar</a></td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
