<?php
// 
$host = "sql303.infinityfree.com";
$user = "if0_41883543";
$pass = "gcchristR17";
$db   = "if0_41883543_hotel_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$conn->set_charset("utf8");
?>
