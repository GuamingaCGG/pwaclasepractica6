<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hotel Guaminga - Experiencia de lujo</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Inter', sans-serif; background: #0a0a0a; color: #fff; overflow-x: hidden; }

    /* ── NAVBAR ── */
    .navbar {
      position: fixed; top: 0; width: 100%; z-index: 100;
      padding: 18px 40px;
      background: linear-gradient(to bottom, rgba(0,0,0,0.85), transparent);
      transition: background 0.4s;
    }
    .navbar.scrolled { background: rgba(10,10,10,0.97); padding: 12px 40px; }
    .navbar-brand { font-family: 'Playfair Display', serif; font-size: 1.6rem; color: #c9a84c !important; letter-spacing: 2px; }
    .nav-link { color: rgba(255,255,255,0.8) !important; font-size: 0.85rem; letter-spacing: 1px; text-transform: uppercase; margin: 0 10px; transition: color 0.3s; }
    .nav-link:hover { color: #c9a84c !important; }
    .btn-reserve {
      background: #c9a84c; color: #0a0a0a; font-weight: 700;
      padding: 10px 28px; border-radius: 2px; font-size: 0.82rem;
      letter-spacing: 1.5px; text-transform: uppercase; border: none;
      transition: all 0.3s; text-decoration: none;
    }
    .btn-reserve:hover { background: #e2c47a; color: #0a0a0a; transform: translateY(-1px); }

    /* ── HERO ── */
    .hero {
      height: 100vh; position: relative; overflow: hidden;
      display: flex; align-items: center; justify-content: center;
    }
    .hero-bg {
      position: absolute; inset: 0;
      background: linear-gradient(135deg, #0a0a0a 0%, #1a1208 40%, #0d0d0d 100%);
    }
    /* Geometric decorative lines */
    .hero-bg::before {
      content: ''; position: absolute; inset: 0;
      background-image:
        linear-gradient(rgba(201,168,76,0.04) 1px, transparent 1px),
        linear-gradient(90deg, rgba(201,168,76,0.04) 1px, transparent 1px);
      background-size: 80px 80px;
    }
    .hero-bg::after {
      content: ''; position: absolute;
      width: 600px; height: 600px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(201,168,76,0.12) 0%, transparent 70%);
      top: 50%; left: 50%; transform: translate(-50%, -50%);
    }
    .hero-content { position: relative; z-index: 2; text-align: center; padding: 20px; }
    .hero-tag {
      display: inline-block;
      border: 1px solid rgba(201,168,76,0.5);
      color: #c9a84c; font-size: 0.75rem; letter-spacing: 4px;
      text-transform: uppercase; padding: 6px 20px; margin-bottom: 30px;
    }
    .hero-title {
      font-family: 'Playfair Display', serif;
      font-size: clamp(3rem, 7vw, 6rem);
      font-weight: 700; line-height: 1.05;
      color: #fff; margin-bottom: 20px;
    }
    .hero-title em { color: #c9a84c; font-style: italic; }
    .hero-subtitle { color: rgba(255,255,255,0.55); font-size: 1rem; font-weight: 300; letter-spacing: 1px; margin-bottom: 45px; max-width: 500px; margin-left: auto; margin-right: auto; }
    .hero-buttons { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
    .btn-primary-custom {
      background: #c9a84c; color: #0a0a0a; font-weight: 700;
      padding: 15px 40px; border-radius: 2px; font-size: 0.85rem;
      letter-spacing: 2px; text-transform: uppercase; text-decoration: none;
      transition: all 0.3s; display: inline-block;
    }
    .btn-primary-custom:hover { background: #e2c47a; color: #0a0a0a; transform: translateY(-2px); box-shadow: 0 10px 30px rgba(201,168,76,0.3); }
    .btn-outline-custom {
      border: 1px solid rgba(255,255,255,0.3); color: rgba(255,255,255,0.8);
      font-weight: 400; padding: 14px 38px; border-radius: 2px; font-size: 0.85rem;
      letter-spacing: 2px; text-transform: uppercase; text-decoration: none;
      transition: all 0.3s; display: inline-block;
    }
    .btn-outline-custom:hover { border-color: #c9a84c; color: #c9a84c; }

    /* Scroll indicator */
    .scroll-indicator {
      position: absolute; bottom: 40px; left: 50%; transform: translateX(-50%);
      display: flex; flex-direction: column; align-items: center; gap: 8px; z-index: 2;
    }
    .scroll-indicator span { font-size: 0.7rem; letter-spacing: 3px; color: rgba(255,255,255,0.4); text-transform: uppercase; }
    .scroll-line { width: 1px; height: 50px; background: linear-gradient(to bottom, rgba(201,168,76,0.8), transparent); animation: scrollAnim 2s ease-in-out infinite; }
    @keyframes scrollAnim { 0%,100%{opacity:0;transform:scaleY(0);transform-origin:top} 50%{opacity:1;transform:scaleY(1)} }

    /* ── STATS BAR ── */
    .stats-bar { background: #111; border-top: 1px solid #1e1e1e; border-bottom: 1px solid #1e1e1e; padding: 30px 0; }
    .stat-item { text-align: center; }
    .stat-number { font-family: 'Playfair Display', serif; font-size: 2.2rem; color: #c9a84c; font-weight: 700; }
    .stat-label { font-size: 0.75rem; letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,0.4); margin-top: 4px; }
    .stat-divider { width: 1px; background: #2a2a2a; align-self: stretch; }

    /* ── SERVICES ── */
    .services { background: #0d0d0d; padding: 100px 0; }
    .section-tag { font-size: 0.72rem; letter-spacing: 4px; text-transform: uppercase; color: #c9a84c; margin-bottom: 12px; }
    .section-title { font-family: 'Playfair Display', serif; font-size: clamp(2rem, 4vw, 3rem); color: #fff; margin-bottom: 16px; }
    .section-line { width: 50px; height: 1px; background: #c9a84c; margin: 0 auto 50px; }

    .service-card {
      background: #141414; border: 1px solid #1e1e1e;
      padding: 40px 30px; transition: all 0.4s; position: relative; overflow: hidden;
    }
    .service-card::before {
      content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 2px;
      background: #c9a84c; transform: scaleX(0); transition: transform 0.4s;
    }
    .service-card:hover { border-color: #2a2a2a; transform: translateY(-4px); box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
    .service-card:hover::before { transform: scaleX(1); }
    .service-icon { font-size: 2rem; margin-bottom: 20px; }
    .service-card h5 { font-family: 'Playfair Display', serif; font-size: 1.2rem; color: #fff; margin-bottom: 12px; }
    .service-card p { color: rgba(255,255,255,0.45); font-size: 0.9rem; line-height: 1.7; }

    /* ── ROLES ── */
    .roles-section { background: #0a0a0a; padding: 100px 0; }
    .role-card {
      border: 1px solid #1e1e1e; padding: 35px 20px; text-align: center;
      transition: all 0.3s; cursor: default;
    }
    .role-card:hover { border-color: rgba(201,168,76,0.4); background: rgba(201,168,76,0.04); }
    .role-card .icon { font-size: 2.2rem; margin-bottom: 14px; }
    .role-card .role-name { font-family: 'Playfair Display', serif; font-size: 1rem; color: #c9a84c; margin-bottom: 8px; }
    .role-card .role-desc { font-size: 0.8rem; color: rgba(255,255,255,0.35); line-height: 1.6; }

    /* ── CTA ── */
    .cta-section {
      padding: 100px 0; text-align: center;
      background: linear-gradient(135deg, #0f0c03 0%, #1a1208 50%, #0f0c03 100%);
      position: relative; overflow: hidden;
    }
    .cta-section::before {
      content: ''; position: absolute; inset: 0;
      background: radial-gradient(ellipse at center, rgba(201,168,76,0.08) 0%, transparent 70%);
    }
    .cta-section .content { position: relative; z-index: 1; }
    .cta-section h2 { font-family: 'Playfair Display', serif; font-size: clamp(2rem, 5vw, 3.5rem); color: #fff; margin-bottom: 20px; }
    .cta-section p { color: rgba(255,255,255,0.5); font-size: 1rem; margin-bottom: 40px; }

    /* ── FOOTER ── */
    footer {
      background: #050505; border-top: 1px solid #1a1a1a;
      padding: 40px 0; text-align: center;
    }
    footer .brand { font-family: 'Playfair Display', serif; font-size: 1.3rem; color: #c9a84c; margin-bottom: 8px; }
    footer p { color: rgba(255,255,255,0.25); font-size: 0.8rem; }
  </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg" id="mainNav">
  <a class="navbar-brand" href="#">✦ GUAMINGA</a>
  <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
    <span style="color:#c9a84c; font-size:1.4rem;">☰</span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="navMenu">
    <ul class="navbar-nav me-4">
      <li class="nav-item"><a class="nav-link" href="#servicios">Servicios</a></li>
      <li class="nav-item"><a class="nav-link" href="#roles">Sistema</a></li>
      <li class="nav-item"><a class="nav-link" href="login.php">Ingresar</a></li>
    </ul>
    <a href="register.php" class="btn-reserve">Registrarse</a>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-content">
    <div class="hero-tag">Sistema de Reservas</div>
    <h1 class="hero-title">Hotel <em>Guaminga</em></h1>
    <p class="hero-subtitle">Gestión elegante de habitaciones, reservas y usuarios en un solo sistema.</p>
    <div class="hero-buttons">
      <a href="login.php" class="btn-primary-custom">Iniciar Sesión</a>
      <a href="register.php" class="btn-outline-custom">Crear Cuenta</a>
    </div>
  </div>
  <div class="scroll-indicator">
    <span>Scroll</span>
    <div class="scroll-line"></div>
  </div>
</section>

<!-- STATS -->
<section class="stats-bar">
  <div class="container">
    <div class="row align-items-center g-3">
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number">5</div>
        <div class="stat-label">Roles de usuario</div>
      </div>
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number">24/7</div>
        <div class="stat-label">Disponibilidad</div>
      </div>
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number">∞</div>
        <div class="stat-label">Reservas online</div>
      </div>
      <div class="col-6 col-md-3 stat-item">
        <div class="stat-number">100%</div>
        <div class="stat-label">Web responsive</div>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="services" id="servicios">
  <div class="container">
    <div class="text-center mb-5">
      <div class="section-tag">Funcionalidades</div>
      <h2 class="section-title">Todo lo que necesitas</h2>
      <div class="section-line"></div>
    </div>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="service-card">
          <div class="service-icon">🛏</div>
          <h5>Gestión de Habitaciones</h5>
          <p>Agrega, edita y controla disponibilidad de habitaciones. Visualiza precios y tipos en tiempo real.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-card">
          <div class="service-icon">📅</div>
          <h5>Reservas en Línea</h5>
          <p>Los clientes pueden buscar disponibilidad, elegir fechas y realizar reservas desde cualquier dispositivo.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-card">
          <div class="service-icon">👥</div>
          <h5>Control de Usuarios</h5>
          <p>Administra perfiles, asigna roles y supervisa todas las operaciones del personal del hotel.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-card">
          <div class="service-icon">📦</div>
          <h5>Gestión de Suministros</h5>
          <p>Los proveedores registran y ofertan insumos. Mantén el inventario del hotel siempre al día.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-card">
          <div class="service-icon">🔐</div>
          <h5>Acceso por Roles</h5>
          <p>Cada usuario accede solo a lo que le corresponde. Sistema seguro con sesiones PHP.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="service-card">
          <div class="service-icon">📊</div>
          <h5>Panel Administrativo</h5>
          <p>El administrador supervisa usuarios, reservas y habitaciones desde un dashboard centralizado.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ROLES -->
<section class="roles-section" id="roles">
  <div class="container">
    <div class="text-center mb-5">
      <div class="section-tag">Permisos</div>
      <h2 class="section-title">Roles del Sistema</h2>
      <div class="section-line"></div>
    </div>
    <div class="row g-3 justify-content-center">
      <div class="col-6 col-md-2">
        <div class="role-card">
          <div class="icon">🔐</div>
          <div class="role-name">Administrador</div>
          <div class="role-desc">Acceso total al sistema</div>
        </div>
      </div>
      <div class="col-6 col-md-2">
        <div class="role-card">
          <div class="icon">🏢</div>
          <div class="role-name">Gerente</div>
          <div class="role-desc">Habitaciones y precios</div>
        </div>
      </div>
      <div class="col-6 col-md-2">
        <div class="role-card">
          <div class="icon">🖥</div>
          <div class="role-name">Recepcionista</div>
          <div class="role-desc">Reservas y clientes</div>
        </div>
      </div>
      <div class="col-6 col-md-2">
        <div class="role-card">
          <div class="icon">🧍</div>
          <div class="role-name">Cliente</div>
          <div class="role-desc">Busca y reserva</div>
        </div>
      </div>
      <div class="col-6 col-md-2">
        <div class="role-card">
          <div class="icon">📦</div>
          <div class="role-name">Proveedor</div>
          <div class="role-desc">Oferta suministros</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="content">
    <h2>¿Listo para comenzar?</h2>
    <p>Ingresa al sistema con tu cuenta o crea una nueva.</p>
    <div class="d-flex gap-3 justify-content-center flex-wrap">
      <a href="login.php" class="btn-primary-custom">Iniciar Sesión</a>
      <a href="register.php" class="btn-outline-custom">Crear Cuenta</a>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="brand">✦ GUAMINGA</div>
  <p>© 2026 Hotel Guaminga — PHP · Bootstrap 5 · MySQL · JavaScript</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Navbar scroll effect
  window.addEventListener('scroll', () => {
    document.getElementById('mainNav').classList.toggle('scrolled', window.scrollY > 50);
  });
  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      document.querySelector(a.getAttribute('href'))?.scrollIntoView({ behavior: 'smooth' });
    });
  });
</script>
</body>
</html>