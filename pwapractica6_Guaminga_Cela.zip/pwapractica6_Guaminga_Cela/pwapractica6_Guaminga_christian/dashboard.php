<?php
// dashboard.php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];
$name = $_SESSION['user_name'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Hotel</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark px-3">
  <span class="navbar-brand"> Hotel Guaminga</span>
  <span class="text-white"> <?= htmlspecialchars($name) ?> (<?= htmlspecialchars($role) ?>)</span>
  <a href="logout.php" class="btn btn-outline-light btn-sm">Salir</a>
</nav>

<div class="container mt-4">
  <h4>Bienvenido, <?= htmlspecialchars($name) ?></h4>
  <div class="row g-3 mt-2">

    <?php if ($role === 'Administrator'): ?>
      <div class="col-md-4">
        <a href="php/users.php" class="btn btn-primary w-100 p-3"> Gestionar Usuarios</a>
      </div>
    <?php endif; ?>

    <?php if (in_array($role, ['Administrator', 'Hotel Manager'])): ?>
      <div class="col-md-4">
        <a href="php/rooms.php" class="btn btn-success w-100 p-3">🛏 Gestionar Habitaciones</a>
      </div>
    <?php endif; ?>

    <?php if (in_array($role, ['Administrator', 'Hotel Manager', 'Receptionist'])): ?>
      <div class="col-md-4">
        <a href="php/bookings.php" class="btn btn-warning w-100 p-3"> Ver Reservas</a>
      </div>
    <?php endif; ?>

    <?php if (in_array($role, ['Customer', 'Receptionist'])): ?>
      <div class="col-md-4">
        <a href="php/make_booking.php" class="btn btn-info w-100 p-3"> Hacer Reserva</a>
      </div>
    <?php endif; ?>

    <?php if ($role === 'Supplier'): ?>
      <div class="col-md-4">
        <a href="php/supplies.php" class="btn btn-secondary w-100 p-3"> Mis Suministros</a>
      </div>
    <?php endif; ?>

    <?php if ($role === 'Customer'): ?>
      <div class="col-md-4">
        <a href="php/my_bookings.php" class="btn btn-outline-primary w-100 p-3"> Mis Reservas</a>
      </div>
    <?php endif; ?>

  </div>
</div>
</body>
</html>